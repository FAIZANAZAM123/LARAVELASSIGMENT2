<?php
namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Artisan;
use Database\Seeders\DummyDataSeeder;
class TableController extends Controller
{
    public function index()
    {
        $tables = DB::select('SHOW TABLES');
        $tableNames = array_map(function($table) {
            return $table->{'Tables_in_' . env('DB_DATABASE')};
        }, $tables);
        
        return view('Tableviews', compact('tableNames'));
    }

    public function seed(Request $request, $tableName)
    {
        $seeder = new DummyDataSeeder();
        $seeder->run($tableName);
        return redirect()->route('success', ['table' => $tableName]);

    }
    
    public function deletedata(Request $request, $tableName)
    {
        DB::table($tableName)->delete();
        return redirect()->route('delsuccess', ['table' => $tableName]);

    }
    public function success($tableName)
    {
       return view('success')->with('message', 'seed of table named: '.$tableName.' is executed.');
    }
    public function delsuccess($tableName)
    {
       return view('success')->with('message', 'Data of table named:'.$tableName.' is deleted');
    }
    
}
