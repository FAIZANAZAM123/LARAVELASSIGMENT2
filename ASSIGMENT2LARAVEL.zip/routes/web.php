<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\TableController;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "web" middleware group. Make something great!
|
*/

Route::get('/',[TableController::class, 'index'])->name('index');
Route::post('/seed/{table}', [TableController::class, 'seed'])->name('seed');

Route::post('/deletedata/{table}', [TableController::class, 'deletedata'])->name('deletedata');


Route::get('/success/{table}', [TableController::class, 'success'])->name('success');
Route::get('/delsuccess/{table}', [TableController::class, 'delsuccess'])->name('delsuccess');


