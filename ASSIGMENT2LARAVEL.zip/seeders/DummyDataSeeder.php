<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class DummyDataSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    
     public function run($tableName): void
     {

        if($tableName == 'countries' || $tableName == 'countries2')
        {
            for ($i=0; $i <20 ; $i++) { 
                
            
            DB::table($tableName)->insert([
                'name' => \Str::random(10),
                'created_at' => now(),
                'updated_at' => now(),
            ]);
        }
    }
        elseif($tableName == 'examples')
        {
            $statuss = ['active','inactive'];
            for ($i=0; $i <20 ; $i++) { 
                
            
            DB::table($tableName)->insert([
               
                'name' => \Str::random(10),
                'age' => rand(18, 65),
                'is_active' => rand(0, 1),
                'email' => \Str::random(10).'@gmails.com',
                'status' => $statuss[rand(0, 1)],
                'created_at' => now(),
                'updated_at' => now(),
            ]); 
        }  
    }
        elseif($tableName == 'products')
        {
            for ($i=0; $i <20 ; $i++) { 
                
            
            DB::table($tableName)->insert([
                'product_name' => \Str::random(10),
               
                'created_at' => now(),
                'updated_at' => now(),
            ]); 
        }
    }
        elseif($tableName=='states')
        {
            for ($i=0; $i <20 ; $i++) { 
               
            
            DB::table($tableName)->insert([
                'country_id' => rand(376,395),
                'name'=>\Str::random(10),
                'created_at' => now(),
                'updated_at' => now(),
            ]); 
        }
        }
        elseif($tableName=='users')
        {
            for ($i=0; $i <20 ; $i++) { 
              
            
            DB::table($tableName)->insert([
                
                'name'=>\Str::random(10),
                'email' => \Str::random(10).'@gmails.com',
                'email_verified_at'=>now(),
                'password' => \Hash::make('password'),

                'created_at' => now(),
                'updated_at' => now(),
            ]); 
        }
    }
    }
}
